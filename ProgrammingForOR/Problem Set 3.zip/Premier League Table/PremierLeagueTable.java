public class PremierLeagueTable {

	public static void main(String[] args) {
		String TeamName[]=TeamName();
		int resultGame[][]=GameResult();
		Team teams[]=new Team[TeamName.length];
		// create teams
		for(int i=0;i<TeamName.length;i++)
			teams[i]=new Team(TeamName[i],i);
		// match scores
		for(int i=0;i<teams.length;i++) {
			for(int j=0;j<teams.length;j++) {
				  if(i!=j) {
					  teams[i].match(resultGame[i][j], true);
					  teams[i].match(resultGame[j][i], false);
				  }
			}
		}
		
		FindPositions(teams);
		// print teams
		PrintRanking(teams);

	}
	public static int[][] GameResult() {
		int resultD[]= new int[]{12,24,14,34,20,21,43,13,22,23,14,14,12,43,41,41,42,1,30,10,32,44,11,10,10,1,32,44,24,40,2,
				                34,43,44,21,34,14,32,30,33,10,22,32,20,22,43,4,30,41,30,13,41,32,31,1,42,22,24,13,32,22,13,
				                2,13,12,32,13,44,13,1,23,30,3,43,20,4,43,3,40,1,42,44,21,10,40,32,40,14,20,43,32,30,13,20,
				                22,40,30,32,21,14,42,2,24,2,11,13,4,0,42,44,43,10,30,4,43,42,41,44,20,0,14,24,42,33,13,1,
				                33,11,20,41,4,12,40,31,2,33,13,44,12,20,1,1,34,20,12,30,0,33,24,33,23,14,14,24,23,4,11,13,
				                21,4,23,12,32,24,12,11,22,24,32,23,2,11,20,13,34,0,42,14,22,34,21,42,11,11,3,0,13,13,31,10,
				                21,0,42,23,10,22,44,11,31,43,32,24,40,23,2,12,22,22,21,14,12,21,12,13,14,10,11,0,42,10,4,4,
				                14,22,41,24,20,43,32,12,0,4,21,33,14,0,12,33,30,10,41,24,12,32,1,43,32,32,44,24,44,34,3,42,10,
				                1,21,34,4,41,0,0,13,44,3,13,22,12,13,33,14,40,23,43,0,11,1,43,20,40,41,14,22,30,0,41,14,4,31,34,
				                4,42,44,10,1,34,30,4,23,12,31,32,1,34,1,41,33,3,43,11,23,4,24,21,34,41,22,24,34,22,33,41,21,32,
				                42,10,10,4,41,30,2,2,4,34,3,40,30,43,33,21,31,31,0,42,40,34,0,41,22,1,4,24,23,10,1,13,32,23,32,
				                3,31,30,0,2,41,3,10,1,1,3,4,41,40,40,23,41,41,23,3,40,41,30,21,12,2,21,24,43,40,1,22,41,20,4,33,
				                2,41,44,24,22};
        int Result[][]=new int [20][20];
        int index=0;
        for(int i=0;i<20;i++)
        	for(int j=0;j<20;j++) {
        		Result[i][j]=resultD[index];
        		index++;
        	}
        return Result;
        		}
	public static String[] TeamName() {
		String TeamName[]={"Arsenal","Bournemouth","Brighton Hove Albion","Burnley","Cardiff City","Chelsea","Crystal Palace","Everton","Fulham",
				           "Huddersfield Town","Leicester City","Liverpool","Manchester City","Manchester United","Newcastle United","Southampton",
				           "Tottenham Hotspur","Watford","West Ham United","Wolverhampton Wanderers"};
        return TeamName;
	}
    public static void FindPositions(Team teams[]) {
    	for(int i=0;i<teams.length;i++) {
    		int position=1;
    		for(int j=0;j<teams.length;j++) {
    			if(i!=j) {
    				if(teams[i].IsHighRanking(teams[j])==false) {
    					position=position+1;
    				}
    			}
    		}
    		teams[i].position=position;
    	}
    }
    public static void PrintRanking(Team teams[]) {
    	for(int position=1;position<teams.length+1;position++) {
    		for(int i=0;i<teams.length;i++) {
    			if(teams[i].position==position) {
    				teams[i].print();
    			}
    		}
    		
    	}
    }
}