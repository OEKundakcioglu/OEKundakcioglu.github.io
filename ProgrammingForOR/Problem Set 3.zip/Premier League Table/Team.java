
public class Team {
String name;
int id;
int played=0;
int won=0;
int drawn=0;
int lost=0;
int GF=0;
int GA=0;
int GD=0;
int position=1;
int point=0;
Team(String name,int id){
	this.name=name;
	this.id=id;
}
public void match(int score, boolean homegame) {
	int macthScore[]=macthScore(score);
	int Gf;
	int Ga;
	if(homegame) {
		Gf=macthScore[0];
		Ga=macthScore[1];
	}
	else {
		Gf=macthScore[1];
		Ga=macthScore[0];
	}
	this.GF=this.GF+Gf;
	this.GA=this.GA+Ga;
	this.GD=this.GD+Gf-Ga;
	this.played=this.played+1;
	if(Gf-Ga>0) {
		this.won=this.won+1;
		this.point=this.point+3;
	}
	else if(Gf-Ga<0) {
		this.lost=this.lost+1;
	}
	else {
		this.drawn=this.drawn+1;
		this.point=this.point+1;
	}
	
}
public int[] macthScore(int value) {
	int score[]=new int[2];
	score[0]=value/10;
	score[1]=value%10;
	return score;
}
public void print() {
	//1. Team A Played:38 Won:37 Drawn:0 Lost:1 GF:105 GA:15 GD:90 Points:111
	System.out.println(this.position+". "+this.name+" Played: "+this.played+" Won: "+this.won+" Drawn: "+this.drawn+" Lost: "+this.lost+" GF: "+this.GF
			+" GA: "+this.GA+" GD: "+this.GD+" Points: "+this.point);
}
public boolean IsHighRanking(Team B) { // if current team has better ranking, return true.
	boolean check=false;
	if(this.point>B.point) {
		check=true;
	}
	else if(this.point==B.point) {
		if(this.GD>B.GD) {
			check=true;
		}
		else if(this.GD==B.GD) {
			if(this.GF>B.GF) {
				check=true;
			}
		}
	}
	
	return check;
}
}
