
public class Q3_Main {
  /*Write a program that would print the information (name, year of joining,
	salary, address) of three employees by creating a class named 'Employee'.*/ 
	public static void main(String[] args) {
		Q3_Employee employees[]=new Q3_Employee[3];
		employees[0]=new Q3_Employee("Robert",1994,5000,"64C- Wall Street");
		employees[1]=new Q3_Employee("Sam",2000,7000,"68D- Wall Street");
		employees[2]=new Q3_Employee("John",1999,3000,"26B- Wall Street");
		
		for(int i=0;i<employees.length;i++) {
			employees[i].print();
		}
	}

}
