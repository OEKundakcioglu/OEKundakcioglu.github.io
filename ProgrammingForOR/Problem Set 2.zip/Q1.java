
public class Q1 {
	/* Write a Java program to print an array after changing the rows and
	columns of a given two-dimensional array.
	 Original Array:
	 10 20 30
	 40 50 60
	 After changing the rows and columns of the said array:
	 10 40
	 20 50
	 30 60*/
	public static void main(String[] args) {
		 int array1[][]= {{10,20,30},{40,50,60}};
		 int array2[][]=new int[array1[0].length][array1.length];
		 for(int i=0;i<array2.length;i++) {
			 for(int j=0;j<array2[i].length;j++) {
				 array2[i][j]=array1[j][i];
			 }
		 }
		 for(int i=0;i<array2.length;i++) {
			 for(int j=0;j<array2[i].length;j++) {
				 System.out.print(array2[i][j]+" ");
			 }
			 System.out.println();
		 } 
		 

	}

}
