//name, year of joining,salary, address) 
public class Q3_Employee {
   String name; 
   int yearOfJoin;
   int salary;
   String adress;
   Q3_Employee( String name,int yearOfJoin,int salary,String adress){
	   this.name=name; 
	   this.yearOfJoin=yearOfJoin; 
	   this.salary=salary; 
	   this.adress=adress;
   }
   public void print() {
	   System.out.println(this.name+" "+this.yearOfJoin+" "+this.adress);
   }
}
