
public class Q2 {
     /*
      Write a Java program to check if three given side lengths (integers) can
      make a triangle or not.
      Expected Output:
      Input side1: 5
      Input side2: 6
      Input side3: 8
      Is the said sides form a triangle: true
      
      note that the Triangle Inequality Theorem states that the sum of any 2 sides of a triangle must be greater than the measure of the third side.
      */
	public static void main(String[] args) {
		int side1=5;
		int side2=6;
		int side3=8;
		isTrianglePrint(side1,side2,side3);
	}
	public static void isTrianglePrint(int side1,int side2,int side3) {
		System.out.println("Input side1: "+ side1);
		System.out.println("Input side2: "+ side2);
		System.out.println("Input side3: "+ side3);
		System.out.println("Is the said sides form a triangle: "+ isTriangle(side1,side2,side3));
	}
	public static boolean isTriangle(int side1,int side2,int side3) {
		boolean check=true; 
		   if(side1+side2<side3) {
			   check=false;
		   }
		   else if(side1+side3<side2) {
			   check=false;
		   }
		   else if(side2+side3<side1) {
			   check=false;
		   }
		   return check;
	}
	

}
